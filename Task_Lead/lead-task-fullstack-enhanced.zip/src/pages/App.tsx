import React from "react";

const App = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Lead Enquiry Form</h1>
      {/* Lead form component here */}
      {/* Lead list component here */}
    </div>
  );
};

export default App;